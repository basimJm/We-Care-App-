package com.example.mapd722_group2_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
