class RoutesName {
  static const String afterSplashRoute = "/";
  static const String homeRoute = "/home";
  static const String registerRoute = "/register";
  static const String loginRoute = "/login";
  static const String addNewPatientRoute = "/add-new-patient";
}
